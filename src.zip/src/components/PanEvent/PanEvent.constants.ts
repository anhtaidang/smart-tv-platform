export const GRID_SIZE = 1920;
export const NUMBER_OF_COLUMNS = 5;
export const EMIT_KEY_DOWN_INTERVAL = 30;
export const THROTTLE_DELAY_MS = 30;
