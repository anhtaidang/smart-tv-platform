import { ThemeProvider } from '@emotion/react';
import { NavigationContainer } from '@react-navigation/native';
import { useWindowDimensions } from 'react-native';
import { GoBackConfiguration } from './components/GoBackConfiguration';
import { theme } from './design-system/theme/theme';
import { Home } from './pages/Home';
import { ProgramGridPage } from './pages/ProgramGridPage';
import { Menu } from './components/Menu/Menu';
import { MenuProvider } from './components/Menu/MenuContext';
import styled from '@emotion/native';
import { useFonts } from './hooks/useFonts';
import { BottomTabBarProps, createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { ProgramInfo } from './modules/program/domain/programInfo';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ProgramDetail } from './pages/ProgramDetail';
import { NonVirtualizedGridPage } from './pages/NonVirtualizedGridPage';
import { GridWithLongNodesPage } from './pages/GridWithLongNodesPage';
import { useTVPanEvent } from './components/PanEvent/useTVPanEvent';

const Stack = createNativeStackNavigator<RootStackParamList>();

const Tab = createBottomTabNavigator<RootTabParamList>();

export type RootTabParamList = {
    Home: undefined;
    ProgramGridPage: undefined;
    NonVirtualizedGridPage: undefined;
    GridWithLongNodesPage: undefined;
};

export type RootStackParamList = {
    TabNavigator: undefined;
    ProgramDetail: { programInfo: ProgramInfo };
};

const RenderMenu = (props: BottomTabBarProps) => <Menu {...props} />;

const TabNavigator = () => {
    return (
        <MenuProvider>
            <Tab.Navigator
                screenOptions={{
                    headerShown: false,
                }}
                initialRouteName="Home"
                tabBar={RenderMenu}
                sceneContainerStyle={{
                    marginLeft: theme.sizes.menu.closed,
                    backgroundColor: theme.colors.background.main,
                }}
            >
                <Tab.Screen name="Home" component={Home} />
                <Tab.Screen name="ProgramGridPage" component={ProgramGridPage} />
                <Tab.Screen name="NonVirtualizedGridPage" component={NonVirtualizedGridPage} />
                <Tab.Screen name="GridWithLongNodesPage" component={GridWithLongNodesPage} />
            </Tab.Navigator>
        </MenuProvider>
    );
};

function App(): JSX.Element {
    useTVPanEvent();
    const { height, width } = useWindowDimensions();
    const areFontsLoaded = useFonts();

    if (!areFontsLoaded) {
        return null;
    }

    return (
        <NavigationContainer independent>
            <ThemeProvider theme={theme}>
                <GoBackConfiguration />

                <Container width={width} height={height}>
                    <Stack.Navigator
                        screenOptions={{
                            headerShown: false,
                            contentStyle: {
                                backgroundColor: theme.colors.background.main,
                            },
                        }}
                        initialRouteName="TabNavigator"
                    >
                        <Stack.Screen name="TabNavigator" component={TabNavigator} />
                        <Stack.Screen name="ProgramDetail" component={ProgramDetail} />
                    </Stack.Navigator>
                </Container>
            </ThemeProvider>
        </NavigationContainer>
    );
}

export default App;

const Container = styled.View<{ width: number; height: number }>(({ width, height }) => ({
    width,
    height,
    flexDirection: 'row-reverse',
    backgroundColor: theme.colors.background.main,
}));
