import { theme } from './theme';
export type Theme = typeof theme;
