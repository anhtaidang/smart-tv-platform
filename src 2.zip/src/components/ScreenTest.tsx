import React from 'react';
import {Text, View} from 'react-native';

const ScreenTest = () => {
    return (
        <View
            style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
            }}>
            <Text style={{color:'red'}}>Hello, 32312 32 dsad ádsa world!</Text>
        </View>
    );
};
export default ScreenTest;

