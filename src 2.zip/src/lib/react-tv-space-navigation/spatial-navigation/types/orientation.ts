export type NodeOrientation = 'horizontal' | 'vertical';
