export type SpatialNavigationNodeRef = {
  focus: () => void;
};
